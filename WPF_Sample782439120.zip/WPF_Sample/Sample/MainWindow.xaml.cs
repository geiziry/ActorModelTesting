﻿using Syncfusion.UI.Xaml.Charts;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections;

namespace Sample1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }

    public class StackedStepLineSeries : StepLineSeries
    {
        protected override void OnDataSourceChanged(IEnumerable oldValue, IEnumerable newValue)
        {
            int index = Area.Series.IndexOf(this);

            if (index > 0 && ItemsSource != Data)
                UpdateDataSource(index);
            else
                base.OnDataSourceChanged(oldValue, newValue);
        }

        private void UpdateDataSource(int seriesIndex)
        {
            Data.Clear();

            var previousSeriesData = Area.Series[seriesIndex - 1].ItemsSource as ObservableCollection<Model>;
            var currentData = ItemsSource as ObservableCollection<Model>;

            for (int i = 0; i < previousSeriesData.Count; i++)
            {
                Data.Add(new Model() { XData = currentData[i].XData, YData = previousSeriesData[i].YData + currentData[i].YData });
            }

            ItemsSource = Data;
        }

        public ObservableCollection<Model> Data { get; set; }
        public StackedStepLineSeries()
        {
            Data = new ObservableCollection<Model>();
        }
    }

    public class Model
    {
        public DateTime XData { get; set; }
        public double YData { get; set; }
    }

    public class ViewModel
    {
        public ViewModel()
        {
            GenerateData();           
        }

        public void GenerateData()
        {
            Data = new ObservableCollection<Model>();
            Random rd = new Random();
            DateTime dt = new DateTime(2010, 1, 1);
            for (int i = 0; i < 6; i++)
            {
                Data.Add(new Model()
                {
                    XData = dt.AddDays(i),
                    YData = rd.Next(0, 50)
                });
            }
        }

        private ObservableCollection<Model> data;

        public ObservableCollection<Model> Data
        {
            get { return data; }
            set { data = value;  }
        }

        
       
    }
    
}
